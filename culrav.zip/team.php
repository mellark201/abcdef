<?php
$title = "Team | Culrav";
if(($_SERVER['REQUEST_METHOD'] === 'GET') or (isset($_POST['action']) and $_POST['action'] != "getContentPage")){
    include_once('components/header.php');
}
?>
<style>
.celeb-image > img{max-height:405px;width:auto;}
</style>
<section style="margin-top:70px;">
    <div id="about_us" style="margin-bottom:0">
        <div class="nightmare" data-aos="fade-down" data-aos-anchor-placement="top-center"><h1 class="friday" style="animation:unset;">Without &nbsp;involvement,<br>there &nbsp;is &nbsp;no &nbsp;commitment.</h1><br><p>Despite for all the problems and barriers, the team behind this event who are working hard to make this event possible.</p></div>
</section>

<section class="celebs">
    <center style="margin:50px 0"><h1><span class="nightmare">Professor In-charge</span></h1></center>
    <div class="flex" style="margin-top:0;">

        <div class="celeb">
            <div class="celeb-image">
                <div class="" style="filter:unset;"><img src="images/team/BCKLESS_PRof_Abhishek.png"></div>
                <div class="celeb-work nightmare">Professor in-charge</div>
                <div class="celeb-social-links">
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Prof. Abhishek Kumar</h3></div>
            <div class="celeb-details"></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class="" style="filter:unset;"><img src="images/team/BCKLESS_PSAC.png"></div>
                <div class="celeb-work nightmare">Professor in-charge</div>
                <div class="celeb-social-links">
                  
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Prof. Rajesh Gupta</h3></div>
            <div class="celeb-details"></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class="" style="filter:unset;"><img src="images/team/skgupta.png"></div>
                <div class="celeb-work nightmare">Faculty Coordinator</div>
                <div class="celeb-social-links">
                  
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Dr. S.K. Gupta</h3></div>
            <div class="celeb-details"></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class="" style="filter:unset;"><img src="images/team/amani.png"></div>
                <div class="celeb-work nightmare">Treasurer</div>
                <div class="celeb-social-links">
                  
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Dr. Ashutosh Mani</h3></div>
            <div class="celeb-details"></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class="" style="filter:unset;"><img src="images/team/suantak.png"></div>
                <div class="celeb-work nightmare">Member</div>
                <div class="celeb-social-links">
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Dr. Suantak Kamsonlian</h3></div>
            <div class="celeb-details"></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class="" style="filter:unset;"><img src="images/team/jyotsna.png"></div>
                <div class="celeb-work nightmare">Member</div>
                <div class="celeb-social-links">
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Dr. Jyotsna Sinha</h3></div>
            <div class="celeb-details"></div>
        </div>

    </div>
    <center style="margin:50px 0"><h1><span class="nightmare">Festival Secretary</span></h1></center>
    <div class="flex" style="margin-top:0;">

        <div class="celeb">
            <div class="celeb-image">
                <div class=""><img src="images/team/Avinash.png"></div>
                <div class="celeb-work nightmare">Festival Secretary</div>
                <div class="celeb-social-links">
                    <a href="https://www.facebook.com/profile.php?id=100005587684536"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.instagram.com/avi_sharma_._"><i class="fa fa-instagram"></i></a>
                    <a href="mailto:culrav2021@gmail.com"><i class="fa fa-envelope"></i></a>
                    <a href="tel:+918918299688"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Avinash Sharma</h3></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class=""><img src="images/team/Fares.png"></div>
                <div class="celeb-work nightmare">Festival Secretary</div>
                <div class="celeb-social-links">
                    <a href="https://www.facebook.com/faresmanzarkhan"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.instagram.com/faresmanzarkhan/"><i class="fa fa-instagram"></i></a>
                    <a href="mailto:culrav2021@gmail.com"><i class="fa fa-envelope"></i></a>
                    <a href="tel:+966571606718"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Fares Manzar Khan</h3></div>
            <div class="celeb-details"></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class=""><img src="images/team/Manas.png"></div>
                <div class="celeb-work nightmare">Festival Secretary</div>
                <div class="celeb-social-links">
                    <a href="https://www.facebook.com/manas.sharma.mili"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.instagram.com/manas.sharmaa/"><i class="fa fa-instagram"></i></a>
                    <a href="mailto:culrav2021@gmail.com"><i class="fa fa-envelope"></i></a>
                    <a href="tel:+919452460030"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Manas Sharma</h3></div>
            <div class="celeb-details"></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class=""><img src="images/team/Shivangi.png"></div>
                <div class="celeb-work nightmare">Festival Secretary</div>
                <div class="celeb-social-links">
                    <a href="https://www.facebook.com/shivangi.jha.792"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.instagram.com/ishivangiiiiii/"><i class="fa fa-instagram"></i></a>
                    <a href="mailto:culrav2021@gmail.com"><i class="fa fa-envelope"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Shivangi Jha</h3></div>
        </div>

        <div class="celeb">
            <div class="celeb-image">
                <div class=""><img src="https://i.ibb.co/7VgWwsD/IMG-20210310-152346-removebg-preview.png"></div>
                <div class="celeb-work nightmare">Festival Secretary</div>
                <div class="celeb-social-links">
                    <a href="mailto:culrav2021@gmail.com"><i class="fa fa-envelope"></i></a>
                    <a href="tel:+917260950476"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Vikram Pratap Singh</h3></div>
        </div>
    </div>

    
    <center style="margin:50px 0"><h1><span class="nightmare">Design Team</span></h1></center>
    <div class="flex" style="margin-top:0;">
    
        <div class="celeb">
            <div class="celeb-image">
                <div class="" style="filter:unset;"><img src="images/team/Nilotpal.png"></div>
                <div class="celeb-work nightmare">Design Team</div>
                <div class="celeb-social-links">
                    <a href="https://www.facebook.com/nilotpal.mukherjee.50"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.instagram.com/_nilotpal_404"><i class="fa fa-instagram"></i></a>
                    <a href="tel:+919297848673"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Nilotpal Mukherjee</h3></div>
        </div>

    </div>

    <center style="margin:50px 0">
        <h1>
            <span>Web Team</span>
        </h1>
    </center>

    <div class="flex" style="margin-top:0;">

        <div class="celeb" style="width: 12%">
            <div class="celeb-image">
                <div class=""><img src="images/team/Abhay.png"></div>
                <div class="celeb-work nightmare">Web Team</div>
                <div class="celeb-social-links">
                    <a href="https://www.instagram.com/katheriaabhay/"><i class="fa fa-instagram"></i></a>
                    <a href="tel:+917055550124"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Abhay Katheria</h3></div>
        </div>

        <div class="celeb" style="width: 12%">
            <div class="celeb-image">
                <div class=""><img src="images/team/Arpit.png"></div>
                <div class="celeb-work nightmare">Web Team</div>
                <div class="celeb-social-links">
                    <a href="https://www.instagram.com/arpitbaranwaal/"><i class="fa fa-instagram"></i></a>
                    <a href="tel:+917571819104"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Arpit Anand</h3></div>
        </div>
        
        <div class="celeb" style="width: 12%">
            <div class="celeb-image">
                <div class=""><img src="images/team/Himanshu.png"></div>
                <div class="celeb-work nightmare">Web Team</div>
                <div class="celeb-social-links">
                    <a href="https://www.instagram.com/he_man_shu180599/"><i class="fa fa-instagram"></i></a>
                    <a href="tel:+917086040412"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Himanshu Singh</h3></div>
        </div>
        
        <div class="celeb" style="width: 12%">
            <div class="celeb-image">
                <div class=""><img src="images/team/Vishwajeet.png"></div>
                <div class="celeb-work nightmare">Web Team</div>
                <div class="celeb-social-links">
                    <a href="https://www.instagram.com/vishu_1208/"><i class="fa fa-instagram"></i></a>
                    <a href="tel:+918340782670"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <div class="celeb-name"><h3 class="nightmare">Vishwajeet Kumar</h3></div>
        </div>
        

    </div>

</section>
<?php
if(($_SERVER['REQUEST_METHOD'] === 'GET') or (isset($_POST['action']) and $_POST['action'] != "getContentPage")){
    include_once('components/footer.php');
}
?>
