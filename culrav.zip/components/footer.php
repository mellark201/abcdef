</section>
<footer>
    <div class="flex" style="justify-content:center;">
        <div>
            <span style="margin:25px 0;font-size:xx-large;" class="nightmare">CULRAV </span><span style="font-size:x-large;" class="sangkury">2022</span><br>
            <span style="margin:12px 0;font-size:x-large;" class="nightmare">Motilal Nehru National Institute of Technology Allahabad</span><br>
            <span style="margin:12px 0;fonr-size:x-large;" class="nightmare">Prayagraj, Uttar Pradesh</span> - 211004
        </div>
        <div>
            <hr>
            <h5>culrav2022@gmail.com</h5>
            <br>
            <div class="social-links">
                <a href="https://facebook.com/mnnit.culrav" class="fa fa-facebook"></a>
                <a href="https://instagram.com/culrav" class="fa fa-instagram"></a>
                <a href="mailto:culrav2021@gmail.com"><i class="fa fa-envelope"></i></a>
            </div>
        </div>
        <div>
            <hr>
            <div>
                <div class="quick-link"><a>Privacy Policy</a></div>&middot;
                <div class="quick-link"><a>Terms and Conditions</a></div>&middot;
                <div class="quick-link"><a>Cancellation/Refund Policy</a></div>&middot;
                <div class="quick-link"><a href="faq">FAQs</a></div>&middot;
                <div class="quick-link"><a href="contacts">Contact Us</a></div>
            </div><br>
            <h5>&copy; Culrav 2022, MNNIT all rights reserved.</h5>
        </div>
    </div>
</footer>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="scripts/index.js"></script>
</body>
</html>
